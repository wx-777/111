- removeClassFromElement: 
  - create a function that takes in an element, and the class to remove from that element.
  - It should use the removeClass method, not toggle

- toggleClassOnElement: 
  - create a function that takes in an element and a class.
  - It toggles the class on the target element

- hideElements: 
  - create a function that takes in two parameters
  - The target, and the removal type.
    - hide: hides the element but doesn't remove it
    - removeChildren: removes all children elements from the target, but leaves the element there
    - removeSelf: erases the element itself

- addAttributeToElement: 
  - given an element, an attribute, and a value change the targetted element to the appropriate key/value
  - for example: addAttributeToElement('#test','hi','bye')
  - would make the #test element have an attribute 'hi' with a value of 'bye', like the following:
    - <div id="#test" "hi"="bye">

- addAttributeToElement: 
  - given an element, an attribute, and a value change the targetted element to the appropriate key/value for example: 
  - addAttributeToElement('#test','hi','bye')
    - would make the #test element have an attribute 'hi' with a value of 'bye', like the following:
    - <div id="#test" "hi"="bye">


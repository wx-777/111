## Recursive Numeric Spirals

Build a function that takes one parameter and prints out the Fibonacci sequence based on the input parameter. 

- Write a recursive fibonacci sequence without looking one up
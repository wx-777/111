

function changeElements('.numConvert'){
 var elemText =  $('.numConvert').text();
 switch(elemText){
   case  'one': {
     $('.numConvert').text("1");
     break;
   }
   case 'two': {
     $('.numConvert').text("2");
     break;
   }
   case 'three': {
     $('.numConvert').text("3");
     break;
   }
   case 'four': {
     $('.numConvert').text("4");
     break;
   }
   case 'five': {
     $('.numConvert').text("5");
     break;
   }
   case 'six': {
     $('.numConvert').text("6");
     break;
   }
   case 'seven': {
     $('.numConvert').text("7");
     break;
   }
   case 'eight': {
     $('.numConvert').text("8");
     break;
   }
   case 'nine': {
     $('.numConvert').text("9");
     break;
   }
 }
}

function appendTextToElement(){

}

function addClass(){
}

function removeElements(){

}

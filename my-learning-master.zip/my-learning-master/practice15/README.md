# numeric_toggles

Given the following function call:
- numeric_toggles(2);

And the resulting output:
- [4, 6, -9, -12, 16, 20, -25, -30];

Create a function definition that achieves the output with the given input.

<a href="http://jsbin.com/kaqona/edit?html,js,output" target="_blank">Solution Set</a>

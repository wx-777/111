## longest common string

Build a function that takes in two strings and finds the longest common string between them

- Write a function that takes one two parameters
	- Parameter 1 - a string of letters
  - Parameter 2 - a string of letters
- The function should return the longest common string between the two strings
- Example: 
	- lcs('abcdefg','abc') returns 'abc'
  - lcs('abdefghij','abefgh') returns 'efgh' because that is a longer string than 'ab' which is also common

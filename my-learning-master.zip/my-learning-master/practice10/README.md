# permutations

Given the following function call:
- permutations('abc');

And the resulting output:
- ["abc", "acb", "bac", "bca", "cab", "cba"];

Create a function definition that achieves the output with the given input. 

<a href="http://jsbin.com/xinoro/9/edit?html,js,output" target="_blank">Solution Set</a>



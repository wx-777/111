## find middle of string

Build a function, find_middle_letters, that finds the middle of a string.  If the string is an odd number of characters, it returns 1 letter.  If it is an even number of characters, it returns 2 characters.  It takes a string as a parameter


- Example:
	- find_middle_letters('seven')
		- Return: 'v'
	- find_middle_letters('dish')
		- Return: 'is'
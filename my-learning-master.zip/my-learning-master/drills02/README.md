- countOccurences: 
	- given an array of words and a separate word, count how many times a particular word given occurs within that array for example:
	- input ['dog','cat','dog','pig','canary','cat','dog'], 'dog' 
	- returns 3

- wordLengths: 
	- given an array of words, return an array of numbers representing the length of each word For example: 
	- input ['canary','silly','dog','a','mellow']) 
	- return [6,5,3,1,6]

- getMinMaxMean: given an array of numbers, get the minimum, maximum, and mean numbers. Return them as an object. Mean is another word for average For example:
	- input [3,1,9,12,4] 
	- return: {min: 1, max: 12, mean: 25.8}

- findMode: Given an array of numbers, find the number that occurs the most often for example: 
	- input [5,2,7,18,2,42,5,2] 
	- returns 2, since it occurs 3 times. If 2 numbers occur the same amount, return the last one
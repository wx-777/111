

var dependencies = [
  {
    name: 'superCool',
    dependencies: [
      'awesome',
      'stdio',
      'moocow'
    ]
  },
  {
    name: 'mrMan',
    dependencies: [
      'sayWhat',
      'stdio',
      'iPity'
    ]
  },
  {
    name: 'moocow',
    dependencies: [
      'bovine',
      'quadrapated'
    ]
  },
  {
    name: 'stdio',
    dependencies: [
      'c_lib',
      'keys',
    ]
  }
]

## Dependencies

- write code that takes the dependecies listed in dependecies.js
- put them into an array the preserves the proper dependency injection order.
- example output: 
  - ['awesome', 'c_lib', 'keys', 'stdio', 'bovine', 'quadrapated', 'moocow', 'sayWhat', 'iPity']


